export function createDiscussionUI({state,api,esc,receive,render,targets,drafts,storage,navigate}){
 const $=s=>document.querySelector(s),replyIds=new Map(),picked=new Map();let menu=[],active=0,anchor=null,editing=null;
 const people=g=>[...new Set([...(g.mode==='team'?g.members:g.members.map(id=>({product:'employee-merchandise',insight:'employee-profit',content:'employee-creative',service:'employee-service'}[id]||id))),...(g.participants||[])])];
 const settings=g=>({revision:1,pinnedIds:[],excludedIds:[],note:'',maxMessages:12,maxChars:12000,...g.chatContext});
 const post=(g,body)=>api('goals/'+g.id+'/actions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 function toolbar(g){return `<div class="discussion-toolbar"><span>${people(g).length} 位员工 · 自动保存</span><span class="context-auto" title="系统自动筛选目标、近期对话和引用关系，无需手动设置">上下文自动衔接</span><button class="text-button" data-chat-invite="${g.id}">邀请员工</button><button class="text-button" data-chat-export="${g.id}">导出</button></div>`;}
 function composer(g){const m=g.messages.find(m=>m.id===replyIds.get(g.id));return `${m?`<div class="reply-draft">引用 ${esc(m.author)}：${esc(m.text.slice(0,100))}<button type="button" class="text-button" data-chat-unreply="${g.id}">取消引用</button></div>`:''}`;}
 function uploadButton(g){return `<button type="button" class="text-button attach-product" data-product-upload="${esc(g.id)}" title="上传商品参考图" aria-label="添加商品图"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="m8 13 7-7a2.6 2.6 0 0 1 3.7 3.7l-9 9a4.5 4.5 0 0 1-6.3-6.4l9-9"/></svg><span>添加商品图</span></button>`;}
 function modelKey(goalId){
  return 'chat.replyModel:'+encodeURIComponent(storage.getItem('workspaceId')||'default')+':'+goalId;
 }
 function unavailableReason(model){
  if(state.images?.previewOnly)return '仅服务端可用';
  if(model.enabled===false)return '已停用';
  if(!model.credentialConfigured)return model.provider==='codex-local'?'桥接未启用':'未配置密钥';
  if(model.lastTest?.status!=='succeeded'||model.lastTest.revision!==model.revision)return '需测试连接';
  return '';
 }
 function modelPicker(g){
  const models=state.workforce?.models||[],saved=storage.getItem(modelKey(g.id))||'';
  const missing=saved&&!models.some(model=>model.id===saved);
  const options=models.map(model=>{
   const reason=unavailableReason(model);
   return `<option value="${esc(model.id)}" ${model.id===saved?'selected':''} ${reason?'disabled':''}>${esc(model.name)}${reason?' · '+reason:''}</option>`;
  }).join('');
  return `<span class="composer-model"><select id="chat-model" aria-label="对话模型"><option value="" ${saved?'':'selected'}>${state.images?.previewOnly?'模型 · 本地预览':'模型 · 默认'}</option>${missing?`<option value="${esc(saved)}" selected disabled>原模型已移除，请重选</option>`:''}${options}${models.length?'':'<option disabled>尚未配置模型</option>'}<option value="@configure">管理模型连接…</option></select></span>`;
 }
 function selectedModel(){
  const id=$('#chat-model')?.value;
  if(!id)return {};
  const model=state.workforce?.models?.find(m=>m.id===id);
  if(!model||unavailableReason(model))throw new Error('所选对话模型已不可用，请选择其他模型或默认回复。');
  return {chatModelId:id};
 }
 document.addEventListener('change',event=>{
  if(event.target.id!=='chat-model')return;
  const select=event.target,key=modelKey(select.form.dataset.goal);
  if(select.value==='@configure'){
   select.value=storage.getItem(key)||'';
   navigate('ai-config/models');
  }else{
   if(select.value)storage.setItem(key,select.value);
   else storage.removeItem(key);
   const error=$('#chat-error');
   if(error)error.textContent='';
  }
 });
 function controls(m){
  if(!['human','agent','coordinator'].includes(m.role))return '';
  const quoteIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round" aria-hidden="true"><path d="M4 6.5h6v6l-4 5H4.5l2.2-5H4zM14 6.5h6v6l-4 5h-1.5l2.2-5H14z"/></svg>';
  return `<div class="message-actions"><button type="button" class="message-action-icon" data-chat-reply="${esc(m.id)}" aria-label="引用回复" title="引用这条消息">${quoteIcon}<span>引用</span></button></div>`;
 }
 function hide(){menu=[];anchor=null;const m=$('#mention-menu');if(m)m.hidden=true;const input=$('#chat-input');if(input){input.setAttribute('aria-expanded','false');input.removeAttribute('aria-activedescendant');}}
 function candidates(g,query=''){
  const employees=state.workforce?.employees||[],members=people(g),ready=employees.filter(e=>members.includes(e.id)&&e.readiness.ready);
  const all={id:'__all__',name:'所有员工',readiness:{ready:ready.length>0},description:`本群 ${ready.length} 位可回复员工 · 逐位回复，不改变执行计划`};
  return [...(['所有员工','所有人','全体成员','all'].some(name=>name.includes(query.toLowerCase()))?[all]:[]),...employees.filter(e=>e.name.includes(query)||state.workforce.roles.find(r=>r.id===e.roleId)?.name.includes(query)).sort((a,b)=>Number(members.includes(b.id))-Number(members.includes(a.id)))];
 }
 function show(){const input=$('#chat-input'),g=state.goals.find(g=>g.id===input?.form?.dataset.goal);if(!input||!g)return;const prefix=input.value.slice(0,input.selectionStart),match=prefix.match(/(?<![a-zA-Z0-9_.+%-])[@＠]([^@＠\s]{0,60})$/);if(!match){hide();return;}
  anchor={start:Math.max(prefix.lastIndexOf('@'),prefix.lastIndexOf('＠')),end:input.selectionStart};menu=candidates(g,match[1]);active=menu.findIndex(e=>e.readiness.ready);draw();
 }
 function positionMenu(){const list=$('#mention-menu'),input=$('#chat-input');if(!list||list.hidden||!input)return;const rect=input.getBoundingClientRect(),viewport=window.visualViewport,top=viewport?.offsetTop||0,height=viewport?.height||innerHeight,left=viewport?.offsetLeft||0,width=viewport?.width||innerWidth;
  if(rect.bottom<top||rect.top>top+height){hide();return;}const above=rect.top-top-12,below=top+height-rect.bottom-12,useAbove=above>=Math.min(260,below);const available=Math.max(80,Math.min(300,useAbove?above:below));
  list.style.width=Math.min(440,rect.width,width-24)+'px';list.style.left=Math.max(left+12,Math.min(rect.left,left+width-parseFloat(list.style.width)-12))+'px';list.style.maxHeight=available+'px';list.style.top=(useAbove?Math.max(top+8,rect.top-list.offsetHeight-6):rect.bottom+6)+'px';
 }
 function draw(){let list=$('#mention-menu');if(!list){document.body.insertAdjacentHTML('beforeend','<div id="mention-menu" class="mention-menu inline-mention-menu" role="listbox" aria-label="选择要提及的数字员工" hidden></div>');list=$('#mention-menu');}const g=state.goals.find(g=>g.id===$('#chat-input')?.form?.dataset.goal);list.hidden=false;list.innerHTML='<div class="mention-heading">@ 提及员工 <small>↑ ↓ 选择 · Enter 确认</small></div>'+(menu.length?menu.map((e,i)=>`<button type="button" id="mention-option-${i}" role="option" aria-selected="${i===active}" data-chat-pick="${i}" ${e.readiness.ready?'':'disabled'}><strong>${e.id==='__all__'?'@ ':''}${esc(e.name)}</strong><small>${e.id==='__all__'?esc(e.description):e.readiness.ready?(people(g).includes(e.id)?'本群 · ':'发送时加入本群 · ')+esc(e.skillIds.map(id=>state.workforce.skills.find(s=>s.id===id)?.name||id).join('、')):'暂不可用 · 请检查配置'}</small></button>`).join(''):'<p>没有匹配员工，试试姓名或岗位关键词。</p>');const input=$('#chat-input');input.setAttribute('role','combobox');input.setAttribute('aria-autocomplete','list');input.setAttribute('aria-controls','mention-menu');input.setAttribute('aria-expanded','true');if(active>=0)input.setAttribute('aria-activedescendant','mention-option-'+active);else input.removeAttribute('aria-activedescendant');positionMenu();
 }
 function select(index){const e=menu[index],input=$('#chat-input');if(!e?.readiness.ready||!anchor||!input)return;const g=state.goals.find(g=>g.id===input.form.dataset.goal),text='@'+e.name+' ';input.value=input.value.slice(0,anchor.start)+text+input.value.slice(anchor.end);const cursor=anchor.start+text.length;drafts[g.id]=input.value;if(e.id!=='__all__')picked.set(g.id,[...new Set([...(picked.get(g.id)||[]),e.id])]);targets[g.id]='coordinator';$('#chat-target').value='coordinator';hide();input.focus({preventScroll:true});input.setSelectionRange(cursor,cursor);}
 function chooser(){const input=$('#chat-input');if(!input)return;const prefix=input.value.slice(0,input.selectionStart);if(!/(?<![a-zA-Z0-9_.+%-])[@＠]([^@＠\s]{0,60})$/.test(prefix)){const at=input.selectionStart,insert=at&&/[a-zA-Z0-9_.+%-]/.test(input.value[at-1])?' @':'@';input.setRangeText(insert,at,input.selectionEnd,'end');drafts[input.form.dataset.goal]=input.value;}input.focus({preventScroll:true});show();}
 document.addEventListener('input',event=>{if(event.target.id==='chat-input'&&!event.isComposing)show();});
 document.addEventListener('compositionstart',event=>{if(event.target.id==='chat-input')hide();});
 document.addEventListener('compositionend',event=>{if(event.target.id==='chat-input')show();});
 document.addEventListener('click',event=>{if(event.target.id==='chat-input')show();else if(!event.target.closest('#mention-menu,[data-chat-choose]'))hide();});
 document.addEventListener('keyup',event=>{if(event.target.id==='chat-input'&&['ArrowLeft','ArrowRight','Home','End'].includes(event.key)&&!event.isComposing)show();});
 document.addEventListener('keydown',event=>{if(event.isComposing||event.keyCode===229||event.target.id!=='chat-input'||$('#mention-menu')?.hidden!==false)return;if(['ArrowDown','ArrowUp','Enter','Escape'].includes(event.key)){event.preventDefault();event.stopImmediatePropagation();if(event.key==='Escape')hide();else if(event.key==='Enter')select(active);else if(menu.some(e=>e.readiness.ready)){do{active=(active+(event.key==='ArrowDown'?1:-1)+menu.length)%menu.length;}while(!menu[active].readiness.ready);draw();$('#mention-option-'+active)?.scrollIntoView({block:'nearest'});}}},true);
 document.addEventListener('pointerdown',event=>{if(event.target.closest('[data-chat-pick]'))event.preventDefault();});
 document.addEventListener('focusin',event=>{if(event.target.id!=='chat-input'&&!event.target.closest('#mention-menu,[data-chat-choose]'))hide();});
 window.addEventListener('resize',positionMenu);window.addEventListener('scroll',event=>{if(!event.target.closest?.('#mention-menu'))positionMenu();},true);window.visualViewport?.addEventListener('resize',positionMenu);window.visualViewport?.addEventListener('scroll',positionMenu);
 function mount(){if($('#discussion-dialog'))return;document.body.insertAdjacentHTML('beforeend','<dialog id="discussion-dialog" aria-labelledby="discussion-dialog-title"><div class="dialog-head"><h2 id="discussion-dialog-title"></h2><button type="button" class="icon-btn" data-chat-close aria-label="关闭讨论设置">×</button></div><div id="discussion-dialog-body"></div><p id="discussion-error" class="form-error" role="alert"></p></dialog>');}
 async function context(g){mount();editing=g.id;$('#discussion-dialog-title').textContent='对话上下文';$('#discussion-dialog-body').innerHTML='<p>正在读取筛选结果…</p>';$('#discussion-error').textContent='';$('#discussion-dialog').showModal();try{const data=await api('goals/'+g.id+'/context?question='+encodeURIComponent(drafts[g.id]||g.text));if(editing!==g.id||!$('#discussion-dialog').open)return;
  $('#discussion-dialog-body').innerHTML=`<p class="field-hint">完整聊天记录与模型上下文分开保存。当前按引用、固定、最近对话和词项相关性筛选；历史对话不会直接改写业务事实。</p><form id="context-form" data-goal="${g.id}" data-revision="${data.revision}"><label>固定背景（可留空，最多 2000 字）<textarea name="note" rows="3" maxlength="2000">${esc(data.note)}</textarea></label><div class="data-fields"><label>每轮消息上限<select name="maxMessages">${[6,12,20].map(n=>`<option ${n===data.maxMessages?'selected':''}>${n}</option>`).join('')}</select></label><label>历史字符预算<input type="number" name="maxChars" min="4000" max="24000" value="${data.maxChars}" required></label></div><p class="note">本次预览选中 ${data.contextSelection.selected.length} / ${data.contextSelection.totalMessages} 条，约 ${data.contextSelection.characters} 字符。实际提问会重新筛选；固定背景另计，最多 2000 字。</p><details open><summary>查看选中依据与内容</summary>${data.conversation.map(m=>`<div class="context-message"><strong>${esc(m.author)} · ${esc(data.contextSelection.selected.find(s=>s.id===m.id)?.reason||'')}</strong><p>${esc(m.text.slice(0,250))}${m.text.length>250?'…':''}</p></div>`).join('')||'<p>当前没有可带入的对话。保存设置后，发送一条问题开始。</p>'}</details><p class="field-hint">在消息下方可固定 / 排除单条消息，最多固定 6 条。预算不足时固定消息也可能截断，以运行记录中的输入为准。</p><div class="action-buttons"><button class="primary" type="submit">保存设置</button><button class="secondary" type="button" data-chat-reset="${g.id}">开始新话题</button></div><p class="field-hint">新话题会清除固定背景与选中项，停止使用此前对话；聊天历史和业务资料继续保留。</p></form>`;
 }catch(error){$('#discussion-error').textContent=error.message;}}
 document.addEventListener('click',async event=>{const b=event.target.closest('button');if(!b)return;const g=state.goals.find(g=>g.id===state.goal);try{
  if(b.hasAttribute('data-chat-choose')){chooser();return;}
  if(b.hasAttribute('data-chat-pick')){select(Number(b.dataset.chatPick));return;}
  if(b.hasAttribute('data-chat-close')){$('#discussion-dialog').close();editing=null;}
  if(b.dataset.chatReply){targets[g.id]='coordinator';replyIds.set(g.id,b.dataset.chatReply);render(true);$('#chat-input')?.focus();}
  if(b.dataset.chatUnreply){replyIds.delete(g.id);render(true);$('#chat-input')?.focus();}
  if(b.dataset.chatPin||b.dataset.chatExclude){const s=settings(g),id=b.dataset.chatPin||b.dataset.chatExclude,key=b.dataset.chatPin?'pinnedIds':'excludedIds',other=b.dataset.chatPin?'excludedIds':'pinnedIds';s[key]=s[key].includes(id)?s[key].filter(x=>x!==id):[...s[key],id];s[other]=s[other].filter(x=>x!==id);b.disabled=true;receive(await post(g,{kind:'chatContext',...s}));}
  if(b.dataset.chatContext)await context(g);
  if(b.dataset.chatInvite){mount();editing=g.id;$('#discussion-dialog-title').textContent='邀请员工加入讨论';$('#discussion-error').textContent='';$('#discussion-dialog-body').innerHTML='<p class="field-hint">加入后可以 @ 提问，不会自动加入执行计划。</p><div class="invite-list">'+state.workforce.employees.filter(e=>!people(g).includes(e.id)).map(e=>`<button class="secondary" data-chat-add="${e.id}" ${e.readiness.ready?'':'disabled'}><strong>${esc(e.name)}</strong><small>${e.readiness.ready?esc(e.skillIds.map(id=>state.workforce.skills.find(s=>s.id===id)?.name||id).join('、')):'配置未就绪'}</small></button>`).join('')+'</div>';$('#discussion-dialog').showModal();}
  if(b.dataset.chatAdd){const target=state.goals.find(g=>g.id===editing);b.disabled=true;receive(await post(target,{kind:'inviteDiscussion',employeeId:b.dataset.chatAdd}));$('#discussion-dialog').close();editing=null;render(true);}
  if(b.dataset.chatReset){const target=state.goals.find(g=>g.id===editing);b.disabled=true;receive(await post(target,{kind:'chatContext',revision:Number($('#context-form').dataset.revision),reset:true}));replyIds.delete(target.id);$('#discussion-dialog').close();editing=null;render(true);}
  if(b.dataset.chatExport){const blob=new Blob([JSON.stringify({goal:g.text,exportedAt:new Date().toISOString(),messages:g.messages,context:settings(g)},null,2)],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='目标对话-'+g.id+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 }catch(error){if($('#discussion-dialog')?.open)$('#discussion-error').textContent=error.message;else if($('#chat-error'))$('#chat-error').textContent=error.message;b.disabled=false;}});
 document.addEventListener('submit',async event=>{const f=event.target;if(f.id!=='context-form')return;event.preventDefault();const b=event.submitter;b.disabled=true;try{const g=state.goals.find(g=>g.id===f.dataset.goal),data=Object.fromEntries(new FormData(f));receive(await post(g,{kind:'chatContext',revision:Number(f.dataset.revision),...data,maxMessages:Number(data.maxMessages),maxChars:Number(data.maxChars)}));$('#discussion-dialog').close();editing=null;}catch(error){$('#discussion-error').textContent=error.message;}finally{b.disabled=false;}});
 return {people,toolbar,composer,uploadButton,modelPicker,controls,hide,submission:(g,text)=>({...selectedModel(),workforceChat:true,inviteIds:(picked.get(g.id)||[]).filter(id=>!people(g).includes(id)&&(text.includes('@'+state.workforce.employees.find(e=>e.id===id)?.name)||text.includes('＠'+state.workforce.employees.find(e=>e.id===id)?.name))),replyTo:replyIds.get(g.id)||null,mentionIds:(picked.get(g.id)||[]).filter(id=>(text.includes('@'+state.workforce.employees.find(e=>e.id===id)?.name)||text.includes('＠'+state.workforce.employees.find(e=>e.id===id)?.name)))}),sent:id=>{replyIds.delete(id);picked.delete(id);hide();}};
}
