// The old offline prototype is preserved separately from the HTTP-backed platform.
import {copyFile} from 'node:fs/promises';
const base=new URL('../deliverables/',import.meta.url);
for(const name of ['AI数字员工协作工作台.html','慕雅居-交互演示.html'])await copyFile(new URL('历史交互原型_V1.html',base),new URL(name,base));
console.log('历史离线原型已恢复。新版前后端平台请使用 npm start 或启动脚本；npm run pack 生成完整平台包。');
