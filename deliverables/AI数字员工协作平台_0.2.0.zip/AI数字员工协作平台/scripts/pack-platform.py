from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
output=root/'deliverables/AI数字员工协作平台_0.2.0.zip'
files=[root/x for x in ['package.json','README.md','.env.example','.gitignore','start-platform.sh','start-platform.cmd']]
for folder in ['src','public','test','scripts','docs','design-system']:
    files.extend(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.append(root/'deliverables/历史交互原型_V1.html')
with ZipFile(output,'w',ZIP_DEFLATED) as z:
    for p in sorted(set(files)):
        z.write(p,'AI数字员工协作平台/'+str(p.relative_to(root)))
print(f'Created {output.name}: {output.stat().st_size} bytes; excludes runtime data, secrets, Git metadata and dependencies.')
