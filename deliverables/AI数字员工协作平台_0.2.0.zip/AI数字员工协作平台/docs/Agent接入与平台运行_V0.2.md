# Agent接入与平台运行 V0.2

本版是可运行的前后端基础平台。浏览器经HTTP向Node服务提交配置、资料、目标和操作；后端运行Agent并持久化结果。不是只在浏览器中修改演示数组。

## 1. 运行

需要Node.js 22或以上，无第三方运行依赖，不需要先安装模型SDK。

```sh
npm start
```

默认端口3000。Windows可双击`start-platform.cmd`；macOS/Linux执行`bash start-platform.sh`。启动脚本检测到`.env`时读取该文件；直接`npm start`使用进程环境，不会自动读取`.env`。可复制`.env.example`为`.env`后修改。

服务需要保持运行，再在同一台机器的浏览器访问`http://127.0.0.1:3000`。用户下载的ZIP包含完整前后端，双击HTML不能替代运行服务器。

## 2. 建议体验路径

1. 打开“Agent配置”，进入经营分析Agent，修改目标利润率并保存。
2. 修改测试JSON，例如净销售额4000，其他成本合计2400；点运行测试，得到贡献利润1600、利润率40%。把广告费用留空/设null，结果应是等待资料，不默认为0。
3. 新建“分析本周贡献利润”目标；确认计划后，如未提供账单，会进入等待资料。
4. 在资料标签录入账单、来源和统计期间，保存后重新确认计划，后端自动执行；交付物、复盘和运行记录会同步出现。
5. 新建上新目标，选择商品运营和经营分析；录入并确认规格、成本、库存，确认计划后先运行商品校验，再运行经营测算。得到两份有调用来源的成果。
6. 若选择发布前审批，批准后自动提交**模拟店铺**。回读和观察数据仍由演示操作触发，尚未连接电商平台。

## 3. 两个代码型Agent

| Agent | 输入 | 实际处理 | 停止条件 |
| --- | --- | --- | --- |
| product | 已确认材质、规格、来源、成本、库存、售价和SKU | 校验缺项、库存、采购价差率；按已确认事实生成草案 | 缺字段、库存为0、低于配置价差下限 |
| insight | 带来源和统计期间的收入费用账单 | 计算贡献利润、利润率、阈值判断；零销售不除0；缺费用不下结论 | 缺必需金额或来源/期间 |

在上新目标中，若尚无实际经营账单，insight只根据售价与采购成本计算**采购价差**并列观察清单，不把它称为贡献利润。

内置Agent是确定性代码，不调用LLM；文字指令不能修改其执行逻辑。配置页提供实际生效的阈值、启停和超时设置。规则解析只辅助建议分析/上新类型，不等于自然语言动态规划。后续可将同一角色切为HTTP适配器，对接外部模型Agent。

## 4. 自动执行与状态

每个目标由协调器按已确认计划顺序调用Agent。草案执行无需逐步点击“生成”。调用保存agentId、配置版本、目标版本、输入、开始/结束时间、耗时、输出和错误。

- 缺资料：任务等待，展示缺项。补充资料生成新目标版本，重新确认计划后计算。
- Agent停用/错误：停止当前步骤，可检查配置后“重试当前步骤”。已成功步骤不重复执行。
- 目标在执行中被改：旧结果标记discarded，不覆盖新资料。
- 执行中暂停：结果可以保存为waiting_resume；恢复后应用缓存结果，不再次调用同一Agent。
- 服务在执行中重启：未完成调用标记interrupted；相关目标显示失败待重试，不假装成功。已排队任务可继续。
- 只有Agent草案准备已自动化；模拟店铺回读/七天观察仍保留明确的演示控制。完整PRD里的终止、真实多人审批、持续经营等尚未全部实现。

当前调度器是单进程串行调用工作器。不同目标HTTP请求不会被远程调用锁住，但远程Agent耗时会增加其他调用等待时间。多工作器/多进程调度与数据库锁属于后续扩展，不能直接启动多个进程共同写同一JSON目录。

## 5. Agent配置API

所有API在配置`PLATFORM_TOKEN`后要求`Authorization: Bearer <token>`；`GET /api/health`例外。浏览器会提示输入工作空间令牌。无令牌配置时是本地单工作空间模式。

| API | 用途 |
| --- | --- |
| GET /api/agents | 已配置Agent列表、启用状态、revision及凭证是否配置；不返回密钥值 |
| PUT /api/agents/:id | 保存已有角色配置；必须携带当前revision，冲突拒绝 |
| GET /api/agents/:id/sample | 该Agent的测试JSON样例 |
| POST /api/agents/:id/test | 输入`{input: {...}}`，返回202与run id；后端异步执行 |
| GET /api/runs | 运行摘要，不含输入和密钥 |
| GET /api/runs/:id | 本次输入和结构化输出，配置密钥值不保存、不返回 |
| POST /api/goal-preview | 输入`{text}`；返回规则推荐类型、成员、方法和限制 |
| GET /api/goals | 工作空间目标 |
| POST /api/goals | 创建目标，需要稳定requestId；相同请求返回同一个Goal |
| POST /api/goals/:id/actions | 确认资料/计划、重试、审批等；关键修改携带expectedVersion |

配置示例（须先GET取得真实revision）：

```json
{
  "revision": 1,
  "name": "商品运营 Agent",
  "role": "校验商品事实并准备上新草案",
  "enabled": true,
  "adapter": "builtin",
  "timeoutMs": 15000,
  "endpoint": "",
  "secretEnv": "",
  "instructions": "只引用已确认事实",
  "settings": {"minGrossMargin": 10}
}
```

经营分析的settings字段为`targetProfitRate`。当前可配置两个已实现角色；尚未提供任意新角色注册页面。更换执行实现使用对应角色的HTTP适配器，避免创建没有能力契约的空Agent。

## 6. 外部HTTP Agent契约

在配置页选择HTTP适配器，填写HTTPS地址；环境变量`AGENT_ALLOWED_HOSTS`列出精确允许域名，密钥可放`AGENT_SECRET_...`变量。配置页只填写变量名，不填密钥值。域名的云环境网络策略也必须允许访问。

出站请求：`POST <endpoint>`，`Content-Type: application/json`；配置密钥时附Bearer。请求只用于分析、校验和草案生成，**外部Agent不得据此执行平台发布、调价、下单等写操作**；真实业务写入应由另一个受审批控制的执行网关完成。

```json
{
  "schemaVersion": 1,
  "agentId": "product",
  "configVersion": 2,
  "instructions": "只引用已确认事实",
  "settings": {"minGrossMargin": 10},
  "input": {
    "goal": "准备上新资料",
    "kind": "listing",
    "scope": {"store": "试点店", "sku": "SKU-001", "product": "角阀"},
    "facts": {"confirmed": true, "material": "已核验材质", "connector": "已核验规格", "cost": 12, "stock": 200, "source": "供应商规格表"},
    "proposal": {"title": "经确认的商品标题", "price": 29.9},
    "observations": []
  }
}
```

成功响应：

```json
{
  "status": "succeeded",
  "summary": "商品事实核验通过，草案已准备",
  "missing": [],
  "metrics": {"procurementMarginRate": 59.87},
  "artifacts": [{"title": "商品草案", "body": "可审阅的完整内容", "evidence": "供应商规格表"}]
}
```

缺资料响应：

```json
{
  "status": "needs_input",
  "summary": "库存来源缺失，无法继续",
  "missing": ["库存来源"],
  "metrics": {},
  "artifacts": []
}
```

适配器限制：HTTPS、精确域名白名单、不跟随跳转、不接受URL凭证/查询参数、不访问本机及内网地址；HTTP错误正文不存入日志；响应上限256KB，校验状态和成果字段；若响应回显密钥会拒绝保存。密钥读取限`AGENT_SECRET_`前缀。连接、超时、无效JSON或错误响应会作为失败运行记录。

已用可控响应验证协议、出站参数和敏感内容拦截；未连接用户真实外部Agent服务，不声称联调完成。

## 7. 数据保存与现有原型兼容

- `.data/platform.json`保存新版目标、配置、调用记录和创建去重记录；服务端串行事务，先写临时快照再rename，失败不替换内存状态。
- 首次启动若有旧`goals.json`，复制旧目标作为历史演示目标。原文件及旧rooms/tasks保留，不覆盖或删除。
- 历史目标仍走原演示逻辑；**新建目标**走服务端代码Agent运行器。
- 浏览器历史单文件的localStorage与服务端独立，不能自动将它当作服务端已迁移数据。
- 备份应在服务停止后复制整个DATA_DIR。API没有删除配置/历史目标能力。

## 8. 当前交付边界

已具备真实前后端接口、持久化、两个代码Agent、配置测试、调用记录、用户资料录入、计划后自动协作、失败/缺资料恢复、精确版本审批后模拟提交、可选工作空间访问令牌。

未接真实店铺、真实LLM、真实外部Agent、多用户权限/租户、生产数据库、分布式工作流与平台自动回读。工作空间令牌不等于多人账号体系。本版可以用于内部联调与继续开发，不能将示例结果包装成已实现的自主经营业务价值。
